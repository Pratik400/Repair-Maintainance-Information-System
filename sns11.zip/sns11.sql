--
-- Database: `sns11`
--
CREATE DATABASE IF NOT EXISTS `sns11` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `sns11`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `uname`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'guest', 'guest');

-- --------------------------------------------------------

--
-- Table structure for table `hardwarekeyboard`
--

CREATE TABLE `hardwarekeyboard` (
  `id` int(10) NOT NULL,
  `h_name` varchar(30) NOT NULL,
  `myselectbox` varchar(50) NOT NULL,
  `h_price` varchar(30) NOT NULL,
  `h_productdes` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hardwarekeyboard`
--

INSERT INTO `hardwarekeyboard` (`id`, `h_name`, `myselectbox`, `h_price`, `h_productdes`) VALUES
(1, 'zxc', 'Keyboard', 'zxczxc', 'zxczxcz'),
(2, 'prodot k-900', 'Keyboard', 'asdasd', 'asdasdasd'),
(3, 'adsad', 'Keyboard', 'dasdasd', 'asdasd'),
(4, 'dekk', 'Keyboard', '4000', 'ok oko kok o k ok o k i j'),
(5, 'dfhxdfbx', 'Keyboard', '9999999999', '0o00000'),
(6, '111111111111111111111111111', 'Keyboard', '111111111111111111111111111111', '111111111111111111111111111111111111111');

-- --------------------------------------------------------

--
-- Table structure for table `hardwaremouse`
--

CREATE TABLE `hardwaremouse` (
  `id` int(10) NOT NULL,
  `h_name` varchar(30) NOT NULL,
  `myselectbox` varchar(50) NOT NULL,
  `h_price` varchar(30) NOT NULL,
  `h_productdes` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hardwaremouse`
--

INSERT INTO `hardwaremouse` (`id`, `h_name`, `myselectbox`, `h_price`, `h_productdes`) VALUES
(1, '1232w', '', '34534534e', '345345e'),
(2, '1232w3', '', '34534534e3', '345345e3'),
(3, '1232w34', '', '34534534e34', '345345e34'),
(4, '1232w344', '', '34534534e344', '345345e344'),
(5, '1232w344', '', '34534534e344', '345345e344'),
(6, '1232w344e', '', '3453453e4e344', '345345e34e4'),
(7, '1232w344es', '', '3453453e4e344s', '345345e34es4'),
(8, 'asd', '', 'asd', 'asdas'),
(9, '1', 'myoption3', '2', '222'),
(10, 'sa', 'Mouse', '11', 'asd'),
(11, 'sa', 'Mouse', '11', 'asd'),
(12, 'sas', 'Mouse', '11sd', 'asdsd'),
(13, 'ASDAS', 'Mouse', 'FGRFW', 'ASDASDAS'),
(14, '232222', 'Mouse', '2222222222222222', '222222222222222222222222222222');

-- --------------------------------------------------------

--
-- Table structure for table `mainslip`
--

CREATE TABLE `mainslip` (
  `id` int(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sno` varchar(10) DEFAULT NULL,
  `nname` varchar(50) DEFAULT NULL,
  `contactno` varchar(50) DEFAULT NULL,
  `pdes` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `problem` varchar(100) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `receivedby` varchar(50) NOT NULL,
  `checkedby` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mainslip`
--

INSERT INTO `mainslip` (`id`, `date`, `sno`, `nname`, `contactno`, `pdes`, `email`, `problem`, `comment`, `receivedby`, `checkedby`, `status`) VALUES
(6, '2018-07-26 13:06:12', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'ok', 'Unsuccesful'),
(9, '2018-08-19 16:05:36', '3', '3342', 'aaaaa', 'aaaaa', 'aaaaaa', 'aaaaaaaaa', 'aaaaaaaaa', 'aaaaaa', 'aaaaaaaaa', 'Repaired'),
(10, '2018-08-19 16:20:52', '333', '3', '3', '3', '3', '3', '3', '3', '3', 'Repaired'),
(11, '2018-08-19 16:28:11', 'asdasd', 'asdasd123213', '12312', '123', '123', '123', 'JHGV', 'JHGKJ', 'JMBK', 'Not_Repaired'),
(12, '2018-08-19 16:44:32', 'aaaaa', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'Not_Repaired'),
(13, '2018-08-19 16:47:13', 'ASDAS', '12312', 'ASDASDAS`', 'ASDASDQQ134123', 'QWEASDA', 'DSFASDFA', 'SDFSDF', '12312``', 'ADFASD123123', 'Not_Repaired'),
(14, '2018-08-19 16:49:05', '2134213', '23423', '23423', '324234', '23423', '23423', '234234', '234234', '23423', 'Repaired'),
(15, '2018-08-21 13:40:21', '9', 'JKL FYJ', '8 88', 'BJM', 'JKL', 'BHJB CGH\r\n\r\n\r\n', '\r\nGHJ', 'G ASD', 'DSF ASD', 'Not_Repaired'),
(16, '2018-08-21 18:30:43', '112', 'Pratik Bajracharya', '9801234566  5560303', 'DELL INSPIRON 5110', 'emai.email@email.com', 'SERVICING\r\nSCREEN CHANGE\r\nOS INSTALL', 'password: qasdbjzkj\r\nneed before 6 pm tommorrow', 'Technican Man', 'Technican Man two', 'Not_Repaired');

-- --------------------------------------------------------

--
-- Table structure for table `messageslip`
--

CREATE TABLE `messageslip` (
  `id` int(10) NOT NULL,
  `nnname` varchar(30) DEFAULT NULL,
  `eemail` varchar(50) DEFAULT NULL,
  `message` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messageslip`
--

INSERT INTO `messageslip` (`id`, `nnname`, `eemail`, `message`) VALUES
(1, 'rgter', 'ertert', 'erter'),
(2, 'rgter', 'ertert', 'erter'),
(3, 'rgter', 'ertert', 'erter'),
(4, '', '', ''),
(5, 'AP[POSDIJ', 'DFJNSDK B', 'SDKF BSDKFSDHF '),
(6, 'AP[POSDIJ', 'DFJNSDK B', 'SDKF BSDKFSDHF '),
(7, 'ASDAASDDFSBSDB AET ERH DFHDF H', 'DFG DFG AERTERT EARG AERRGDFG DF', 'GDFG DAFG DG RTJ K A AF A ASDF'),
(8, 'dasasdas', 'asdasdasd ada ', 'ada sda tagtasd as'),
(9, 'rammm', 'a@gmail.com', 'asdkjbhaskj ishc asidu aksuhdi'),
(10, '', '', ''),
(11, '', '', ''),
(12, '', '', ''),
(13, '', '', ''),
(14, 'zdcZSDa', 'dasdas da ', ' asd asd asd asd asd asd  asd '),
(15, 'asdasd', 'asdasd', 'aojkokokokokokokokokook'),
(16, '11111111111111111', '11111111111111111111', '1111111111111111111111111111'),
(17, '222222222222222222222', '2222222222222222222222222', '22222222222222222222222222222'),
(18, '900hjkhjk', 'kkkkkkkkkkkkk', 'kgggggggggggg'),
(19, '', '', ''),
(20, '', '', ''),
(21, '123', 'zxczx', 'zxczx'),
(22, 'asd', 'asd', 'asd'),
(23, 'a', 'adsd', 'asdasd'),
(24, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh', '43333333333333333333333333333333333333333 sszfdasd', 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhh'),
(25, 'Pratik bajracharya', 'Email@mail.com', 'ok this is test review\r\n\r\n'),
(26, 'Pratik bajracharya TWO', 'Emaiwwwwwl@mail.com', '\r\n\r\nASDASDASD'),
(27, 'shailkaoisudh', 'akjsdjgsajdg@aslkhdkas.vom', 'akjsdgfjags kluadkjbsak'),
(28, 'asdas basd a', 'asda s341', 'asd asd as'),
(29, '', '', ''),
(30, 'aaaaaaaadsfsdvs', 'q123123', 'xvx');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hardwarekeyboard`
--
ALTER TABLE `hardwarekeyboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hardwaremouse`
--
ALTER TABLE `hardwaremouse`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mainslip`
--
ALTER TABLE `mainslip`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sno` (`sno`);

--
-- Indexes for table `messageslip`
--
ALTER TABLE `messageslip`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hardwarekeyboard`
--
ALTER TABLE `hardwarekeyboard`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `hardwaremouse`
--
ALTER TABLE `hardwaremouse`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `mainslip`
--
ALTER TABLE `mainslip`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `messageslip`
--
ALTER TABLE `messageslip`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
